class gaussian:
    def __init__(self,alpha=[1]):
        self.type = 'gaussian'
        self.num_alpha = len(alpha)
        self.alpha = alpha



