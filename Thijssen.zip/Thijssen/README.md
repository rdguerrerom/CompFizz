# CompFizz
Computational physics exercises following Jos Thijssen's 'Computational Physics' text book.

# Source
All of the codes under /Source are entirely written by Jos Thijssen. Read the 'intro' PDF document for more info. They're free to use and distrubute, but you should keep the headers with his name in them inside all the codes.

# Mine
All of the codes under /Mine are written by me! They are also free to use and distribute, but you can erase my name and claim them as your own! Do whatever you want with them.
